package componentes;

import javax.swing.JLabel;

public class Spinner extends JLabel {
	public Spinner(int x, int y, int width, int height) {
		setBounds(x, y, width, height);
	}
}
